# ZeroptodaltidoTeam's Platformer
 A basic platform game
 
 ## Controls
 
 AD - horizontal movement
 Space - jump

## Special keys
- F5 Save the current game state
- F6 Load the previous state (even across levels)
- F9 View colliders / logic
- F10 God Mode (free camera)
